<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LegController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('legs.legs1');
    }
    public function index2()
    {
        //
        return view('legs.legs11');
    }
    public function index3()
    {
        //
        return view('legs.legs111');
    }
    public function index4()
    {
        //
        return view('legs.legs12');
    }
    public function index5()
    {
        //
        return view('legs.legs121');
    }
    public function index6()
    {
        //
        return view('legs.legs122');
    }
    public function index7()
    {
        //
        return view('legs.legs2');
    }
    public function index8()
    {
        //
        return view('legs.legs3');
    }
    public function index9()
    {
        //
        return view('legs.legs31');
    }
    public function index10()
    {
        //
        return view('legs.legs32');
    }
    public function index11()
    {
        //
        return view('legs.legs321');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
